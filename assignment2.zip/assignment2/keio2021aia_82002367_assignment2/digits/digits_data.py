from . import *

class Digits_Data:

    def __init__(self, relative_path='../data/', data_file_name='digits_data.pkl', batch_size=64):

        self.batch_size = batch_size
        self.index = -1
        
        with open('%s%s' % (relative_path, data_file_name), mode='rb') as f:
            
            digits_data = pkl.load(f)
            
        self.samples = []
        
        for i in range(10):
            for data in digits_data['train'][i]:
                data_vector = data.reshape(-1)
                self.samples.append([data_vector,i])
        # hint: you will need to flatten the images to represent them as vectors (numpy arrays) and pair them with digit labels from the training data
                
        self.shuffle()
        
        self.starts = np.arange(0, len(self.samples), self.batch_size)

    def __iter__(self):
                
        return self

    def __next__(self):

        self.index += 1
        
        if self.index + 1 > len(self.starts):
            
            self.index = -1
            self.shuffle()
            raise StopIteration
            
        inputs = None
        targets = None
        answer = []
        
        for m in range(len(self.samples)):
            preans = np.zeros(10)
            b = self.samples[m][1]
            preans[b] += 1
            answer.append(preans)
            #creating array of answer, with the correct number assinged as 1 and the rest as zero

        features = [self.samples[m][0] for m in range(len(self.samples))]

        inputs = [features[self.starts[i]:self.starts[i+1]] for i in range(self.starts.shape[0] - 1)]
        targets = [answer[self.starts[i]:self.starts[i+1]] for i in range(self.starts.shape[0] - 1)]
        
        # hint: use the starts initialized in the last line of the constructor and the batch size to generate a batch of inputs and the corresponding batch of targets

        return {'inputs': inputs, 'targets': targets}

    def shuffle(self):
        
        random.shuffle(self.samples)
