from . import *

class Digits_Trainer:
    
    def __init__(self, dataset, model):
        
        self.dataset = dataset
        self.model = model
        self.loss = CrossEntropy()
        
    def accuracy(self):

        acc = None
        acc = 100*np.mean([1 if self.model(x) == np.argmax(y) else 0 for x, y in self.dataset.samples])
        # hint: return the accuracy (i.e. the percentage of digits classified correctly) of the current model on the dataset given in the constructor

        return acc
    
    def step(self, lr):

        for param, grad in self.model.params_and_grads():
            
            param -= lr * grad
            
    def train(self, lr, ne):
        
        print('initial accuracy: %.3f\n\n' %(self.accuracy()))
        
        print('training model on data...\n')
        print('='*80+'\n')
    
        for epoch in range(1, ne + 1):

            epoch_loss = 0.0

            for batch in self.dataset:
               
                predicted = None
                output = None
                delta = None
                grads = []
                outputs = []
                targets = batch['targets'][0]
                i = 0
                for item in batch['inputs'][0]:
                    output = self.model.forward(item)
                    predicted = softmax(model.forward(item))
                    outputs.append(predicted)
                    epoch_loss += self.loss.loss(np.array(outputs), np.array(targets[i]))
                    delta = output*(predicted - targets[i])
                    grads.append(delta)
                    i += 1
                # hint: use the model to generate predictions (digit labels) for a batch, and then use the loss given in the constructor to update the epoch_loss variable

                #for item in batch['inputs'][0]:
                #    output = model.forward(item)
                #    predicted = softmax(model.forward(item))
                #    outputs.append(predicted)
                #    epoch_loss += loss.loss([output], np.array(targets[i]))
                #    delta = output*(predicted - targets[i])
                #    grads.append(delta)
                #    i += 1

                grad = None
                grad = np.mean(np.array([grad for grad in grads]), axis=0)
                
                #for item in range(len(batch['inputs'][0])):
                #    for i in range(len(model.layers[0].params['b'])):
                #        grad[i] += self.loss.grad(np.array(outputs[item]), np.array(targets[item]))
                #grad = self.loss.grad(np.array(outputs), np.array(targets))
                # hint: compute the gradient of the loss with respect to its inputs (not the model inputs - watch the lecture video for explanation)

                self.model.backward(grad)
                self.step(lr)
                
            print("""epoch %d:\n
            \t loss = %.3f\n
            \t accuracy=%.3f""" % (epoch, epoch_loss, self.accuracy()))
            
        print('='*80+'\n')
        print('training complete!\n\n')
        print('final accuracy: %.3f' %(self.accuracy()))
