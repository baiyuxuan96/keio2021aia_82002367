from . import *

class Sonar_Data:

    def __init__(self, data_file_path='', data_file_name='sonar_data.pkl'):
                
        self.data = []
        
        with open(data_file_name, 'rb') as f:
            data = pkl.load(f)
        
        for i in range(len(data['m'])):
            self.data.insert(len(self.data), [])
            self.data[len(self.data)-1].insert(1, data['m'][i])
            self.data[len(self.data)-1].insert(2, 1)
        
        for i in range(len(data['r'])):
            self.data.insert(len(self.data), [])
            self.data[len(self.data)-1].insert(1, data['r'][i])
            self.data[len(self.data)-1].insert(2, -1)
        
        self.index = -1
        
        self.shuffle()

    def __iter__(self):
        
        return self

    def __next__(self):
        
        self.index += 1
        if self.index == (len(self.data)-1):
            raise StopIteration
        return self.data[self.index]

    def shuffle(self):
        
        random.shuffle(self.data)
    
    def __len__(self):
        
        return len(self.data)
